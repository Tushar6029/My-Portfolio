const themeColor = document.getElementById("theme-color");

const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

const theme = localStorage.getItem('theme')


if (theme) {
  document.body.classList.add(theme);
}

function changeTheme() {
    
    document.body.classList.toggle('darkTheme');
    if (document.body.classList.contains('darkTheme')) {
      localStorage.setItem('theme', 'darkTheme')
    } else {
      
      localStorage.removeItem('theme')
    }


  }


/* mainBody.onload = () => {
  if (isDarkMode) {
    themeState = 'dark';
    changeTheme()
  }
  if (!isDarkMode) {
    themeState = 'light';
    changeTheme()
  }

  
} */




/* if (isDarkMode) {
  themeState = 'dark';
  changeTheme()
}
if (!isDarkMode) {
  themeState = 'light';
  changeTheme()
}

function changeTheme() {

  if (themeState === 'dark') {
    themeColor.classList.remove('light-theme');
    themeColor.classList.add('dark-theme');
    themeState = 'light';
  } else {
    themeColor.classList.remove('dark-theme');
    themeColor.classList.add('light-theme');
    themeState = 'dark';
  }


} */