
const signUp = document.getElementById("contact-form");
const email1 = document.getElementById("email");

let email ;

signUp.addEventListener('submit', e => {
  e.preventDefault();
  
   email = email1.value.trim();

  validateEmail();
  //console.log(validateEmail(email));
  
  if (!validateEmail(email)) {
    document.getElementById("email-error").style.display = "block" ;
    document.getElementById("email-input").classList.add("error");
  } else {
    document.getElementById("email-error").style.display = "none" ;
    document.getElementById("email-input").classList.add("safe");
    
    //document.getElementById("eOut").innerHTML = email ;
  }
});
function validateEmail(email) {
  var re = /\S+@\S+\.\S+/;
  return re.test(email);
}
function dismisPopup() {
  document.getElementById("signin").style.display = "" ;
    document.getElementById("successPopUp").style.display = "none" ;
}

//console.log(validateEmail('tushar6029@gmail.com'));