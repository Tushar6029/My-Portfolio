const form = document.getElementById("contact-form");

const username = document.getElementById("username");
const nameError = document.getElementById("name-error");
const nameInput = document.getElementById("name-input");

const email = document.getElementById("email");
const emailError = document.getElementById("email-error");
const emailInput = document.getElementById("email-input");

const message = document.getElementById("message");

const mailSubject = document.getElementById("subject");

const rating = document.getElementById("yourRating");
const rates = document.querySelectorAll(".rateBtn");


let emailValue;
let nameValue;
let messageValue;

let rateValue = 0;

let nameTest;
let emailTest;
let messageTest;

let mailBody

let second;
let minute;
let hours;
let day;
let month;
let year;



function currentDate() {
  const date = new Date();

  second = date.getSeconds();
  minute = date.getMinutes();
  hours = date.getHours();
  day = date.getDate();
  month = date.getMonth();
  year = date.getFullYear();
}

/* email.addEventListener("keyup", function test1() {
  validateInputs()
}) */

form.addEventListener('submit', e => {

  e.preventDefault();
  
  validateInputs()
  if (nameTest && emailTest && messageTest) {

    showpopup();

    resetSuccess(username);
    resetSuccess(email);
    resetSuccess(message);
    createMail();
    form.reset();


  }

  //console.log(mailBody);
});

function validateEmail(email) {
  var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());


};

function setError(element, errorMessage) {
  const inputFeild = element.parentElement;
  const errorDisplay = inputFeild.querySelector('.error-info');

  errorDisplay.innerText = errorMessage;
  inputFeild.classList.add('error');
  inputFeild.classList.remove('safe');
};

function setSuccess(element, errorMessage) {
  const inputFeild = element.parentElement;
  const errorDisplay = inputFeild.querySelector('.error-info');

  errorDisplay.innerText = '';
  inputFeild.classList.add('safe');
  inputFeild.classList.remove('error');
};

function resetSuccess(element) {
  const inputFeild = element.parentElement;
  const errorDisplay = inputFeild.querySelector('.error-info');

  errorDisplay.innerText = '';
  inputFeild.classList.remove('safe');
  inputFeild.classList.remove('error');
};


function validateInputs() {
  emailValue = email.value.trim();
  nameValue = username.value.trim();
  messageValue = message.value.trim();


  if (nameValue === '') {
    setError(username, 'username is required');
    nameTest = false;
  } else {
    setSuccess(username);
    nameTest = true;
  }


  if (emailValue === '') {
    setError(email, 'email is required');
    emailTest = false;
  } else if (!validateEmail(emailValue)) {
    setError(email, 'invalid email');
    emailTest = false;
  } else {
    setSuccess(email);
    emailTest = true;
  }

  if (messageValue === '') {
    setError(message, 'text feild is empty');
    messageTest = false;
  } else {
    setSuccess(message);
    messageTest = true;
  }

  //console.log(nameTest, emailTest);
  //console.log(nameTest && emailTest);



}



function createMail() {
  if (nameTest && emailTest && messageTest) {

    currentDate();

    mailBody = {
      Name: nameValue,
      EmailId: emailValue,
      Subject: mailSubject.value,
      Message: messageValue,
      time: hours + ' ' + minute + ' ' + second,
      date: day + ' ' + month + ' ' + year,
      rating: rateValue
    };

  }

}




function showpopup() {
  document.getElementById("contact-form").style.display = "none";
  document.getElementById("successPopUp").style.display = "flex";

  document.getElementById("eOut").innerHTML = emailValue;
}

function dismisPopup() {
  document.getElementById("contact-form").style.display = "";
  document.getElementById("successPopUp").style.display = "none";
  //createMail();
  //form.reset();
  //console.log(mailBody)
  //document.getElementById("rateMeCard").style.display = "grid";
  //document.getElementById("thankYouCard").style.display = "none";

  rateValue = 0;
}

function submitRating() {
  document.getElementById("rateMeCard").style.display = "none";
  document.getElementById("thankYouCard").style.display = "grid";


}




rates.forEach((rate) => {
  rate.addEventListener("click", () => {
    rating.innerHTML = rate.innerHTML;
    rateValue = rate.innerHTML;
  })
})

